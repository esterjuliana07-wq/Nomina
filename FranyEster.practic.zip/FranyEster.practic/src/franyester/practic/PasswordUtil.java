
package franyester.practic;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.SecureRandom;
import java.util.Base64;

public class PasswordUtil {
    private static final String ALG  = "PBKDF2WithHmacSHA256";
    private static final int    ITER = 310_000;
    private static final int    BITS = 256;
 
    /** Genera hash seguro para almacenar en BD */
    public static String hash(String plain) throws Exception {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        byte[] key = derive(plain.toCharArray(), salt, ITER, BITS);
        return "PBKDF2$" + ITER + "$"
             + Base64.getEncoder().encodeToString(salt) + "$"
             + Base64.getEncoder().encodeToString(key);
    }
 
    /** Verifica contraseña contra el hash almacenado */
    public static boolean verify(String plain, String stored) {
        try {
            String[] p = stored.split("\\$");
            if (p.length != 4) return false;
            byte[] salt = Base64.getDecoder().decode(p[2]);
            byte[] exp  = Base64.getDecoder().decode(p[3]);
            byte[] act  = derive(plain.toCharArray(), salt, Integer.parseInt(p[1]), exp.length * 8);
            // Comparación en tiempo constante (anti timing-attack)
            int diff = exp.length ^ act.length;
            for (int i = 0; i < Math.min(exp.length, act.length); i++) diff |= exp[i] ^ act[i];
            return diff == 0;
        } catch (Exception e) { return false; }
    }
 
    private static byte[] derive(char[] pass, byte[] salt, int iter, int bits) throws Exception
    {
        PBEKeySpec spec = new PBEKeySpec(pass, salt, iter, bits);
        byte[] r = SecretKeyFactory.getInstance(ALG).generateSecret(spec).getEncoded();
        spec.clearPassword();
        return r;
    
    }
