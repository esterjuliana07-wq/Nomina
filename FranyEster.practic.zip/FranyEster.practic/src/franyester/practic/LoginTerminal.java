package franyester.practic;


import java.util.Scanner;
import java.sql.*;

/**
 * LOGIN POR TERMINAL
 * Uso: java -cp ".;mysql-connector-j-8.x.jar" LoginTerminal
 */
public class LoginTerminal {

    // ── Configuración ─────────────────────────────────────────────────────────
    static final String URL  = "jdbc:mysql://localhost:3306/secure_login_db?useSSL=false&serverTimezone=UTC";
    static final String USER = "root";       // ← Cambia esto
    static final String PASS = "tu_password"; // ← Cambia esto

    public static void main(String[] args) throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Scanner sc = new Scanner(System.in);

        System.out.println("╔══════════════════════════════╗");
        System.out.println("║      SECURE LOGIN v1.0       ║");
        System.out.println("╚══════════════════════════════╝");

        System.out.print("  Usuario  : ");
        String username = sc.nextLine().trim();

        System.out.print("  Contraseña: ");
        String password = sc.nextLine().trim();

        System.out.println("\n  Verificando...");

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(
                 "SELECT id, password_hash, role FROM users WHERE username = ? AND is_active = 1 LIMIT 1")) {

            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (!rs.next()) {
                System.out.println("  ✗ Usuario no encontrado.\n");
                return;
            }

            String storedHash = rs.getString("password_hash");
            String role       = rs.getString("role");
            int    userId     = rs.getInt("id");

            if (PasswordUtil.verify(password, storedHash)) {
                // Actualizar último login
                try (PreparedStatement up = conn.prepareStatement(
                        "UPDATE users SET last_login = NOW() WHERE id = ?")) {
                    up.setInt(1, userId);
                    up.executeUpdate();
                }
                System.out.println("  ✓ Bienvenido, " + username + "!");
                System.out.println("  Rol     : " + role);
                System.out.println("  Acceso  : Concedido\n");
            } else {
                System.out.println("  ✗ Contraseña incorrecta.\n");
            }

        } catch (SQLException e) {
            System.out.println("  ✗ Error de base de datos: " + e.getMessage());
        }
        {
            
        }
    }
}
