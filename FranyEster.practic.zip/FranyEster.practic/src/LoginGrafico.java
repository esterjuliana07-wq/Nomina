import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class LoginGrafico {

    static final String URL = "jdbc:mysql://localhost:3306/secure_login_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    static final String USER = "root";
    static final String PASS = "admin";

    public static void main(String[] args) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "❌ Driver MySQL no encontrado");
            return;
        }

        System.out.println("SISTEMA READY");

        UIManager.put("OptionPane.background", new Color(20, 15, 35));
        UIManager.put("Panel.background", new Color(20, 15, 35));
        UIManager.put("Button.background", new Color(80, 150, 250));
        UIManager.put("Button.foreground", Color.WHITE);

        mostrarMenuPrincipal();
    }

    private static void mostrarMenuPrincipal() {
        String[] opciones = {"Registrarse", "Login", "Salir"};

        int seleccion = JOptionPane.showOptionDialog(
                null,
                "¿Qué deseas hacer?",
                "SISTEMA DE LOGIN",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                opciones,
                opciones[0]
        );

        if (seleccion == 0) registrar();
        else if (seleccion == 1) login();
        else System.exit(0);
    }

    private static void registrar() {
        JPanel panel = crearPanel("REGISTRO");

        JTextField userField = crearCampo();
        JTextField emailField = crearCampo();
        JPasswordField passField = crearPassword();

        panel.add(label("Usuario:"));
        panel.add(userField);
        panel.add(label("Correo:"));
        panel.add(emailField);
        panel.add(label("Contraseña:"));
        panel.add(passField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Registro", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {

            String password = new String(passField.getPassword());

            try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
                 PreparedStatement st = conn.prepareStatement(
                         "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)")) {

                st.setString(1, userField.getText());
                st.setString(2, emailField.getText());
                st.setString(3, password);

                st.executeUpdate();

                JOptionPane.showMessageDialog(null, "✅ Usuario registrado");

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "❌ Error: usuario o correo ya existe");
            }
        }

        mostrarMenuPrincipal();
    }

    private static void login() {
        JPanel panel = crearPanel("LOGIN");

        JTextField userField = crearCampo();
        JPasswordField passField = crearPassword();

        panel.add(label("Usuario:"));
        panel.add(userField);
        panel.add(label("Contraseña:"));
        panel.add(passField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Login", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {

            try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
                 PreparedStatement st = conn.prepareStatement(
                         "SELECT password_hash FROM users WHERE username = ?")) {

                st.setString(1, userField.getText());
                ResultSet rs = st.executeQuery();

                if (rs.next()) {
                    String passwordDB = rs.getString("password_hash");

                    if (new String(passField.getPassword()).equals(passwordDB)) {
                        JOptionPane.showMessageDialog(null, "🔓 Acceso concedido");
                    } else {
                        JOptionPane.showMessageDialog(null, "❌ Contraseña incorrecta");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "❌ Usuario no existe");
                }

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "❌ Error de conexión");
            }
        }

        mostrarMenuPrincipal();
    }

    // ---------- ESTILO ----------

    private static JPanel crearPanel(String titulo) {
        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
        panel.setBorder(BorderFactory.createTitledBorder(titulo));
        panel.setPreferredSize(new Dimension(300, 200));
        panel.setBackground(new Color(20, 15, 35));
        return panel;
    }

    private static JTextField crearCampo() {
        JTextField campo = new JTextField();
        campo.setBackground(new Color(40, 40, 60));
        campo.setForeground(Color.WHITE);
        return campo;
    }

    private static JPasswordField crearPassword() {
        JPasswordField pass = new JPasswordField();
        pass.setBackground(new Color(40, 40, 60));
        pass.setForeground(Color.WHITE);
        return pass;
    }

    private static JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(Color.WHITE);
        return l;
    }
}